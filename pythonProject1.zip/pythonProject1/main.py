import math
alfa=int(input("Введите значение альфа "))
z1=(math.cos(alfa))+(math.cos(alfa)*2)+(math.cos(alfa)*6)+(math.cos(alfa)*7)
z2=(4*(math.cos(alfa)/2))*(math.cos(alfa)*(5/2))*(math.cos(alfa)*4)
print(z1, z2)





