import math

x = int(input("Введите число х: "))
y = int(input("Введите число y: "))
z = int(input("Введите число z: "))
beta = math.sqrt(10 * (x + (x **(y + 2)))) * ((math.asin(x)**2) - abs(x - y))
print(beta)
