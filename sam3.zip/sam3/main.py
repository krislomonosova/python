import math

x = (input("Введите число х: "))
y = (input("Введите число y: "))
z = (input("Введите число z: "))
if type(x)==int and (y)==int and (z)==int or  type(x)==float and type(y)==float and type(z)==float:
    pass
    print("Введите числовое значение")
else :
    beta = math.sqrt(10 * (x + (x ** (y + 2)))) * ((math.asin(x) ** 2) - abs(x - y))
    print(beta)
