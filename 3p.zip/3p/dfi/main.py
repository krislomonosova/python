import math

# z=int(input("введите число: "))
# if z<0 :
#     x=z
#     y=(2/3)*((math.sin(x)**2)-(3/4)*(math.cos(x)**2))
#     print(y)
# else:
#        x=(math.sin(z))
#        y = (2 / 3) * ((math.sin(x) ** 2) - (3 / 4) * (math.cos(x) ** 2))
#        print(y)
import math
x=int(input("введите значение х: "))
y=int(input("введите значение y: "))
z=int(input("введите значение z: "))
if y>z
    