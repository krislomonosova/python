import math
a=1
b=3
n=10
h=(b-a)/n
x=int(input('введите х: '))
y=((x)**2-4*x+8)/((x)**2-2*x+3)
print(x)
print(y)
print("h=", h)