# import math
# alfa=-1.9
# beta=2.7
# h=0.3
# while alfa<beta:
#     print(f"x={alfa}")
#     x=alfa
#     y=(x**2/4+x/2-3)*math.e**(x/2)
#     print(f"y={y}")
#     alfa=alfa+h
# print("Цикл завершен")

import math
a=0.1
b=1.0
h=0.1
c=0
while a<b:
    k=0
    s=(2*k+1/(math.factorial(k)))*a**(2*k)
    y=(1+2*a**2)*math.e**(a**2)
    c+=s
    print(f"x={a}, s={s}, y={y}, c={c}, n={y-s}")
    a=a+h





