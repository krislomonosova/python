import math
print("задание 1")
a = int(input('введите первое число '))
b = int(input("введите второе число "))
c = (input('введите знак операции для чисел '))
while c!='0' :
    a=int(input('введите первое число'))
    b=int(input("введите второе число "))
    c=(input('введите знак операции для чисел '))
    if c=="/" :
        c=a/b
        print(c)
    else :
        if c=="*" :
            c=a*b
            print(c)
        else :
            if c=="+" :
                c=a+b
                print(c)
            else :
                c=a-b
                print(c)
print("программа завершена")

print("задание 5")
a=int(input('введите число '))
print(f'!а={math.factorial(a)}')

print('задание 2')
a=(input("a="))
even=0
odd=0
for i in a:
    if int(i) % 2==0 :
        even+=1
    else :
        odd +=1
print(f'четных: {even}, нечетных: {odd}')

print('задание 3')
a=int(input('a='))
s=0
m=1
while a>0:
    d=a%10
    s=s+d
    m=m*d
    a=a//10
print(f'сумма: {s}, произведение: {m}')